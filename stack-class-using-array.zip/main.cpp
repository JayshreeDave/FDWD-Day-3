/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
class Stack
{    //properties
          public:       
          int *arr;
          int top;        
          int size;    //behavior
         Stack(int size)
         {        
               this -> size = size;
               arr = new int[size];    
               top =-1;    
    
         }
 
        void push(int element)
       {      
             if(size - top>1)
              {           
                  top++;     
                  arr[top]=element;
              } 
              else       
              cout<<"Stack overflow"<<endl;   
        } 
         
         void pop()
         {
             if(top>=0)      
             top--;
             else 
             cout<<"Stack underflow"<<endl; 
          }
          
           int peek()
           {   
               if(top>=0)
               { 
               return arr[top];      
               }    
               else
               {            
                   cout<<"Stack is  Empty :"<<endl; 
                   return -1; 
                }
            }
                   bool isEmpty()
                   {    
                       if(top ==-1)     
                       return true;
                       else            
                       return false;
                     } 
    
    };
    
    int main()
    {   
        Stack st(5);   
        st.push(34); 
        st.push(89);    
        cout<<st.peek()<<endl;   
        st.pop();  
        cout<<st.peek()<<endl;  
        st.pop(); 
 
 
         cout<<st.peek()<<endl;  
         if(st.isEmpty())        
         cout<<"Stack is empty :"<<endl;   
         else       
         cout<<"Stack is not empty :"<<endl;   
         return 0; 
        
    }
