/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
struct Node
{  
    int val; 
    Node* next; 
}; 

class mystack
{  
    Node* head;  
    int stacksize;  
    public:        //constructor  
       mystack()
       {       
           head = NULL;      
           stacksize=0;  
        }
        
        void push(int element)
        {      
            Node* temp= new Node();       
            temp-> val=element;       
            temp-> next=head;      
            head=temp;       
            cout<<"Element " <<element<<" is inserted" <<endl; 
            stacksize++;   
        }
        void pop()
        {
            if (head==NULL)
            { 
                cout<<"Stack is Empty!" <<endl;
                return;
            } 
            Node* temp=head;
            head = temp->next; 
            temp->next= NULL;
            delete temp;
            cout<<"Element popped!";
            stacksize--; 
         }



         int peek()
         {      
             if (head==NULL)
             {  
                 cout<<"No top element, stack is Empty!"<<endl;         
                 return -1;     
             }      
                 cout<<"Top element is: " <<head->val<<endl;    
                 return head->val; 
        }  
    
        
        int size()
        {        
            cout<<"Size of stack is " <<stacksize<<endl;   
            return stacksize;  
        } 
        int empty()
        {      
            if(head==NULL)
            {            
                cout<<"Stack is empty!" <<endl;      
            }      
            else
            {            
                cout<<"Stack is not empty !"<<endl; 
                 
            }
        }
    };
            
            int main()
            {
                mystack s1; 
                s1.empty();
                s1.push(9); 
                s1.push(18);
                s1.pop(); 
                s1.peek(); 
                s1.size();
                s1.empty();
                return 0;
              }